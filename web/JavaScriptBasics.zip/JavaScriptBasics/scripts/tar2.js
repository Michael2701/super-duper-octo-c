'use strict';

let str = prompt("Please enter a number");
alert(parseInt(str) < 5 ? "Number is smaller then 5" : "Number is bigger or equel 5");
location.reload();











